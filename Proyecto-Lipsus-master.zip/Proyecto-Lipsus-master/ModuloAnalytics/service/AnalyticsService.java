package ModuloAnalytics.service;

import ModuloAnalytics.dto.AnalyticsResponse;
import org.springframework.stereotype.Service;

@Service
public class AnalyticsService {

    public AnalyticsResponse getUserStatistics(Long userId) {

        // Simulación de datos (luego se conectará con Submissions)
        int totalSubmissions = 20;
        int successfulSubmissions = 14;

        double successRate = (double) successfulSubmissions / totalSubmissions * 100;

        double averageScore = 78.5;

        return new AnalyticsResponse(
                userId,
                totalSubmissions,
                successfulSubmissions,
                successRate,
                averageScore
        );
    }
}
