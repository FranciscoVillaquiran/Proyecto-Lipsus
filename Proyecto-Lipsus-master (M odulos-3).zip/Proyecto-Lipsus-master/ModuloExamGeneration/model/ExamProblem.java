package ModuloExamGeneration.model;

import jakarta.persistence.*;

@Entity
public class ExamProblem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long problemId;

    @ManyToOne
    @JoinColumn(name = "exam_id")
    private Exam exam;

    public ExamProblem() {}

    public ExamProblem(Long problemId, Exam exam) {
        this.problemId = problemId;
        this.exam = exam;
    }

    public Long getId() {
        return id;
    }

    public Long getProblemId() {
        return problemId;
    }

    public Exam getExam() {
        return exam;
    }

    public void setProblemId(Long problemId) {
        this.problemId = problemId;
    }

    public void setExam(Exam exam) {
        this.exam = exam;
    }
}
