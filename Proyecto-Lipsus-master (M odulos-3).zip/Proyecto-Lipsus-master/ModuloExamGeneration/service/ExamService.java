package ModuloExamGeneration.service;

import ModuloExamGeneration.dto.ExamRequest;
import ModuloExamGeneration.dto.ExamResponse;
import ModuloExamGeneration.model.Exam;
import ModuloExamGeneration.model.ExamProblem;
import ModuloExamGeneration.repository.ExamRepository;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExamService {

    private final ExamRepository examRepository;

    public ExamService(ExamRepository examRepository) {
        this.examRepository = examRepository;
    }

    public ExamResponse createExam(ExamRequest request) {

        Exam exam = new Exam(
                request.getTitle(),
                request.getDescription(),
                request.getDurationMinutes()
        );

        List<ExamProblem> examProblems = new ArrayList<>();

        for (Long problemId : request.getProblemIds()) {
            ExamProblem examProblem = new ExamProblem(problemId, exam);
            examProblems.add(examProblem);
        }

        exam.setProblems(examProblems);

        Exam savedExam = examRepository.save(exam);

        List<Long> problemIds = savedExam.getProblems()
                .stream()
                .map(ExamProblem::getProblemId)
                .collect(Collectors.toList());

        return new ExamResponse(
                savedExam.getId(),
                savedExam.getTitle(),
                savedExam.getDescription(),
                savedExam.getDurationMinutes(),
                problemIds
        );
    }

    public List<ExamResponse> getAllExams() {

        return examRepository.findAll()
                .stream()
                .map(exam -> new ExamResponse(
                        exam.getId(),
                        exam.getTitle(),
                        exam.getDescription(),
                        exam.getDurationMinutes(),
                        exam.getProblems()
                                .stream()
                                .map(ExamProblem::getProblemId)
                                .collect(Collectors.toList())
                ))
                .collect(Collectors.toList());
    }
}
