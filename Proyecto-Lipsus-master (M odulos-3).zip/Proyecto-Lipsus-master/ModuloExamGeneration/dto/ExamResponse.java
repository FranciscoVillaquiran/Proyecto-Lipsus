package ModuloExamGeneration.dto;

import java.util.List;

public class ExamResponse {

    private Long id;
    private String title;
    private String description;
    private int durationMinutes;
    private List<Long> problemIds;

    public ExamResponse(Long id, String title, String description, int durationMinutes, List<Long> problemIds) {
        this.id = id;
        this.title = title;
        this.description = description;
        this.durationMinutes = durationMinutes;
        this.problemIds = problemIds;
    }

    public Long getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public List<Long> getProblemIds() {
        return problemIds;
    }
}

