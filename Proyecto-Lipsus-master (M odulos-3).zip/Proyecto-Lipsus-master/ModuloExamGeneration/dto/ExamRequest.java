package ModuloExamGeneration.dto;

import java.util.List;

public class ExamRequest {

    private String title;
    private String description;
    private int durationMinutes;
    private List<Long> problemIds;

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public int getDurationMinutes() {
        return durationMinutes;
    }

    public List<Long> getProblemIds() {
        return problemIds;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setDurationMinutes(int durationMinutes) {
        this.durationMinutes = durationMinutes;
    }

    public void setProblemIds(List<Long> problemIds) {
        this.problemIds = problemIds;
    }
}

