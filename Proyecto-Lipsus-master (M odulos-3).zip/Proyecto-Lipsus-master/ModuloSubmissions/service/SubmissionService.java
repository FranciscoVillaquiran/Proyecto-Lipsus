package ModuloSubmissions.service;

import ModuloSubmissions.dto.SubmissionRequest;
import ModuloSubmissions.dto.SubmissionResponse;
import ModuloSubmissions.model.Submission;
import ModuloSubmissions.repository.SubmissionRepository;

import ModuloCodeRunner.dto.CodeExecutionRequest;
import ModuloCodeRunner.dto.CodeExecutionResponse;
import ModuloCodeRunner.service.CodeRunnerService;

import ModuloProblemas.model.Problem;
import ModuloProblemas.model.TestCase;
import ModuloProblemas.service.ProblemService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class SubmissionService {

    private final SubmissionRepository submissionRepository;
    private final CodeRunnerService codeRunnerService;
    private final ProblemService problemService;

    public SubmissionService(
            SubmissionRepository submissionRepository,
            CodeRunnerService codeRunnerService,
            ProblemService problemService
    ) {
        this.submissionRepository = submissionRepository;
        this.codeRunnerService = codeRunnerService;
        this.problemService = problemService;
    }

   public SubmissionResponse createSubmission(SubmissionRequest request) {

    // 1 obtener el problema
    Problem problem = problemService.getProblemEntity(request.getProblemId());

    String finalStatus = "ACCEPTED";

    // 2 ejecutar por cada test case
    for (TestCase testCase : problem.getTestCases()) {

        CodeExecutionRequest execRequest = new CodeExecutionRequest();
        execRequest.setCode(request.getCode());
        execRequest.setLanguage(request.getLanguage());
        execRequest.setInput(testCase.getInput());

        CodeExecutionResponse result = codeRunnerService.runCode(execRequest);

        // si falla ejecución
        if (!result.isSuccess()) {
            finalStatus = "RUNTIME_ERROR";
            break;
        }

        // comparar salida esperada
        String output = result.getOutput().trim();
        String expected = testCase.getExpectedOutput().trim();

        if (!output.equals(expected)) {
            finalStatus = "WRONG_ANSWER";
            break;
        }
    }

    // 3 crear submission
    Submission submission = new Submission(
            request.getUserId(),
            request.getProblemId(),
            request.getCode(),
            request.getLanguage(),
            finalStatus
    );

    // 4 guardar
    Submission saved = submissionRepository.save(submission);

    // 5 respuesta
    return new SubmissionResponse(
            saved.getId(),
            saved.getUserId(),
            saved.getProblemId(),
            saved.getLanguage(),
            saved.getStatus(),
            saved.getSubmittedAt()
    );
}

    public List<SubmissionResponse> getSubmissionsByUser(Long userId) {

        return submissionRepository.findByUserId(userId)
                .stream()
                .map(s -> new SubmissionResponse(
                        s.getId(),
                        s.getUserId(),
                        s.getProblemId(),
                        s.getLanguage(),
                        s.getStatus(),
                        s.getSubmittedAt()
                ))
                .collect(Collectors.toList());
    }

    public List<SubmissionResponse> getSubmissionsByProblem(Long problemId) {

        return submissionRepository.findByProblemId(problemId)
                .stream()
                .map(s -> new SubmissionResponse(
                        s.getId(),
                        s.getUserId(),
                        s.getProblemId(),
                        s.getLanguage(),
                        s.getStatus(),
                        s.getSubmittedAt()
                ))
                .collect(Collectors.toList());
    }
}
