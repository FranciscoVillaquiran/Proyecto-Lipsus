package ModuloExamResolution.repository;

import ModuloExamResolution.model.ExamSubmission;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ExamSubmissionRepository extends JpaRepository<ExamSubmission, Long> {

    List<ExamSubmission> findByUserId(Long userId);

    List<ExamSubmission> findByExamId(Long examId);
