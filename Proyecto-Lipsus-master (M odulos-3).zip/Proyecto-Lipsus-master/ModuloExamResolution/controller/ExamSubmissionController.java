package ModuloExamResolution.controller;

import ModuloExamResolution.dto.ExamSubmissionRequest;
import ModuloExamResolution.dto.ExamSubmissionResponse;
import ModuloExamResolution.service.ExamSubmissionService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/exam-submissions")
public class ExamSubmissionController {

    private final ExamSubmissionService service;

    public ExamSubmissionController(ExamSubmissionService service) {
        this.service = service;
    }

    @PostMapping
    public ExamSubmissionResponse submitExam(@RequestBody ExamSubmissionRequest request) {
        return service.submitExam(request);
    }

    @GetMapping("/user/{userId}")
    public List<ExamSubmissionResponse> getByUser(@PathVariable Long userId) {
        return service.getSubmissionsByUser(userId);
    }

    @GetMapping("/exam/{examId}")
    public List<ExamSubmissionResponse> getByExam(@PathVariable Long examId) {
        return service.getSubmissionsByExam(examId);
    }
}
