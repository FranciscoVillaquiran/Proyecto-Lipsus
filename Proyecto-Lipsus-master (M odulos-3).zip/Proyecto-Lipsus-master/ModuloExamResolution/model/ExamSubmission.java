package ModuloExamResolution.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class ExamSubmission {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long examId;

    private Long userId;

    private String answers;

    private int score;

    private LocalDateTime submittedAt;

    public ExamSubmission() {}

    public ExamSubmission(Long examId, Long userId, String answers) {
        this.examId = examId;
        this.userId = userId;
        this.answers = answers;
        this.submittedAt = LocalDateTime.now();
        this.score = 0;
    }

    public Long getId() {
        return id;
    }

    public Long getExamId() {
        return examId;
    }

    public Long getUserId() {
        return userId;
    }

    public String getAnswers() {
        return answers;
    }

    public int getScore() {
        return score;
    }

    public LocalDateTime getSubmittedAt() {
        return submittedAt;
    }

    public void setScore(int score) {
        this.score = score;
    }
}
