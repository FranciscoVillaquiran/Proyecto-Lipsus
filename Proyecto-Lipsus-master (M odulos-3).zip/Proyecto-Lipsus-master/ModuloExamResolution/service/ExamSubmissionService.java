package ModuloExamResolution.service;

import ModuloExamResolution.dto.ExamSubmissionRequest;
import ModuloExamResolution.dto.ExamSubmissionResponse;
import ModuloExamResolution.model.ExamSubmission;
import ModuloExamResolution.repository.ExamSubmissionRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class ExamSubmissionService {

    private final ExamSubmissionRepository repository;

    public ExamSubmissionService(ExamSubmissionRepository repository) {
        this.repository = repository;
    }

    public ExamSubmissionResponse submitExam(ExamSubmissionRequest request) {

        ExamSubmission submission = new ExamSubmission(
                request.getExamId(),
                request.getUserId(),
                request.getAnswers()
        );

        ExamSubmission saved = repository.save(submission);

        return new ExamSubmissionResponse(
                saved.getId(),
                saved.getExamId(),
                saved.getUserId(),
                saved.getScore(),
                saved.getSubmittedAt()
        );
    }

    public List<ExamSubmissionResponse> getSubmissionsByUser(Long userId) {

        return repository.findByUserId(userId)
                .stream()
                .map(sub -> new ExamSubmissionResponse(
                        sub.getId(),
                        sub.getExamId(),
                        sub.getUserId(),
                        sub.getScore(),
                        sub.getSubmittedAt()
                ))
                .collect(Collectors.toList());
    }

    public List<ExamSubmissionResponse> getSubmissionsByExam(Long examId) {

        return repository.findByExamId(examId)
                .stream()
                .map(sub -> new ExamSubmissionResponse(
                        sub.getId(),
                        sub.getExamId(),
                        sub.getUserId(),
                        sub.getScore(),
                        sub.getSubmittedAt()
                ))
                .collect(Collectors.toList());
    }
}
