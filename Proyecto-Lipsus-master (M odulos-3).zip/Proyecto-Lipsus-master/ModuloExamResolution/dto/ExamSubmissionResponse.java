package ModuloExamResolution.dto;

import java.time.LocalDateTime;

public class ExamSubmissionResponse {

    private Long id;
    private Long examId;
    private Long userId;
    private int score;
    private LocalDateTime submittedAt;

    public ExamSubmissionResponse(Long id, Long examId, Long userId, int score, LocalDateTime submittedAt) {
        this.id = id;
        this.examId = examId;
        this.userId = userId;
        this.score = score;
        this.submittedAt = submittedAt;
    }

    public Long getId() {
        return id;
    }

    public Long getExamId() {
        return examId;
    }

    public Long getUserId() {
        return userId;
    }

    public int getScore() {
        return score;
    }

    public LocalDateTime getSubmittedAt() {
        return submittedAt;
    }
}
