package ModuloExamResolution.dto;

public class ExamSubmissionRequest {

    private Long examId;
    private Long userId;
    private String answers;

    public Long getExamId() {
        return examId;
    }

    public Long getUserId() {
        return userId;
    }

    public String getAnswers() {
        return answers;
    }

    public void setExamId(Long examId) {
        this.examId = examId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setAnswers(String answers) {
        this.answers = answers;
    }
}
