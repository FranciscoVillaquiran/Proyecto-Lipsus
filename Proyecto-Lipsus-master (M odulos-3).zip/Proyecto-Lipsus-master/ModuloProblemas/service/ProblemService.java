package ModuloProblemas.service;


import ModuloProblemas.dto.ProblemRequest;
import ModuloProblemas.dto.ProblemResponse;
import ModuloProblemas.model.Problem;
import ModuloProblemas.repository.ProblemRepository;
import org.springframework.stereotype.Service;

import ModuloProblemas.model.TestCase;
import ModuloProblemas.dto.TestCaseRequest;

import java.util.List;
import java.util.stream.Collectors;


@Service
public class ProblemService {


    private final ProblemRepository problemRepository;


    public ProblemService(ProblemRepository problemRepository) {
        this.problemRepository = problemRepository;
    }


  public ProblemResponse createProblem(ProblemRequest request) {

    Problem problem = new Problem(
            request.getTitle(),
            request.getDescription(),
            request.getDifficulty(),
            request.getTopic()
    );

    // guardar primero el problema
    Problem savedProblem = problemRepository.save(problem);

    // crear test cases
    if (request.getTestCases() != null) {

        List<TestCase> testCases = request.getTestCases()
                .stream()
                .map(tc -> new TestCase(
                        tc.getInput(),
                        tc.getExpectedOutput(),
                        savedProblem
                ))
                .collect(Collectors.toList());

        savedProblem.setTestCases(testCases);
    }

    Problem finalProblem = problemRepository.save(savedProblem);

    return new ProblemResponse(
            finalProblem.getId(),
            finalProblem.getTitle(),
            finalProblem.getDescription(),
            finalProblem.getDifficulty(),
            finalProblem.getTopic()
    );
}


    public List<ProblemResponse> getAllProblems() {


        return problemRepository.findAll()
                .stream()
                .map(problem -> new ProblemResponse(
                        problem.getId(),
                        problem.getTitle(),
                        problem.getDescription(),
                        problem.getDifficulty(),
                        problem.getTopic()
                ))
                .collect(Collectors.toList());
    }


    public ProblemResponse getProblemById(Long id) {


        Problem problem = problemRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Problem not found"));


        return new ProblemResponse(
                problem.getId(),
                problem.getTitle(),
                problem.getDescription(),
                problem.getDifficulty(),
                problem.getTopic()
        );
    }


    public Problem getProblemEntity(Long id) {
        return problemRepository.findById(id).orElseThrow(() -> new RuntimeException("Problem not found"));
    }
}
