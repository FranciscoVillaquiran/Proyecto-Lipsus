package ModuloCodeRunner.service;

import ModuloCodeRunner.dto.CodeExecutionRequest;
import ModuloCodeRunner.dto.CodeExecutionResponse;
import ModuloCodeRunner.model.ExecutionResult;

import org.springframework.stereotype.Service;

@Service
public class CodeRunnerService {

    public ExecutionResult execute(String code, String language, String input) {

        // Simulación de ejecución
        String simulatedOutput = "Execution simulated";

        return new ExecutionResult(
                simulatedOutput,
                true,
                null
        );
    }

    public CodeExecutionResponse runCode(CodeExecutionRequest request) {

        ExecutionResult result = execute(
                request.getCode(),
                request.getLanguage(),
                request.getInput()
        );

        return new CodeExecutionResponse(
                result.getOutput(),
                result.isSuccess(),
                result.getError()
        );
    }
}

