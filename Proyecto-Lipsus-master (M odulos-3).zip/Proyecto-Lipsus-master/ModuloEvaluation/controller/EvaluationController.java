package ModuloEvaluation.controller;

import ModuloEvaluation.dto.EvaluationRequest;
import ModuloEvaluation.dto.EvaluationResponse;
import ModuloEvaluation.service.EvaluationService;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/evaluation")
public class EvaluationController {

    private final EvaluationService evaluationService;

    public EvaluationController(EvaluationService evaluationService) {
        this.evaluationService = evaluationService;
    }

    @PostMapping("/evaluate")
    public EvaluationResponse evaluate(@RequestBody EvaluationRequest request) {
        return evaluationService.evaluate(request);
    }
}
