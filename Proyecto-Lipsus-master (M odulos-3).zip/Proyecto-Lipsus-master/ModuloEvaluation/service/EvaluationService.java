package ModuloEvaluation.service;

import ModuloEvaluation.dto.EvaluationRequest;
import ModuloEvaluation.dto.EvaluationResponse;
import ModuloEvaluation.model.EvaluationResult;

import ModuloCodeRunner.model.ExecutionResult;
import ModuloCodeRunner.service.CodeRunnerService;

import org.springframework.stereotype.Service;

@Service
public class EvaluationService {

    private final CodeRunnerService codeRunnerService;

    public EvaluationService(CodeRunnerService codeRunnerService) {
        this.codeRunnerService = codeRunnerService;
    }

    public EvaluationResponse evaluate(EvaluationRequest request) {

        ExecutionResult executionResult = codeRunnerService.execute(
                request.getCode(),
                request.getLanguage(),
                request.getInput()
        );

        EvaluationResult result = new EvaluationResult();

        if (!executionResult.isSuccess()) {

            result.setStatus("RUNTIME_ERROR");
            result.setPassedTests(0);
            result.setTotalTests(1);
            result.setMessage(executionResult.getError());

        } else {

            String output = executionResult.getOutput().trim();
            String expected = request.getExpectedOutput().trim();

            if (output.equals(expected)) {

                result.setStatus("ACCEPTED");
                result.setPassedTests(1);
                result.setTotalTests(1);
                result.setMessage("Correct output");

            } else {

                result.setStatus("WRONG_ANSWER");
                result.setPassedTests(0);
                result.setTotalTests(1);
                result.setMessage("Output does not match expected result");

            }
        }

        return new EvaluationResponse(
                result.getStatus(),
                result.getPassedTests(),
                result.getTotalTests(),
                result.getMessage()
        );
    }
}
