
package ModuloEvaluation.dto;

public class EvaluationResponse {

    private String status;
    private int passedTests;
    private int totalTests;
    private String message;

    public EvaluationResponse(String status, int passedTests, int totalTests, String message) {
        this.status = status;
        this.passedTests = passedTests;
        this.totalTests = totalTests;
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public int getPassedTests() {
        return passedTests;
    }

    public int getTotalTests() {
        return totalTests;
    }

    public String getMessage() {
        return message;
    }
}
