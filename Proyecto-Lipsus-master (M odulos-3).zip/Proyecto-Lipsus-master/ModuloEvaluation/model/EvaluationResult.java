
package ModuloEvaluation.model;

public class EvaluationResult {

    private String status;
    private int passedTests;
    private int totalTests;
    private String message;

    public EvaluationResult() {}

    public EvaluationResult(String status, int passedTests, int totalTests, String message) {
        this.status = status;
        this.passedTests = passedTests;
        this.totalTests = totalTests;
        this.message = message;
    }

    public String getStatus() {
        return status;
    }

    public int getPassedTests() {
        return passedTests;
    }

    public int getTotalTests() {
        return totalTests;
    }

    public String getMessage() {
        return message;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void setPassedTests(int passedTests) {
        this.passedTests = passedTests;
    }

    public void setTotalTests(int totalTests) {
        this.totalTests = totalTests;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
