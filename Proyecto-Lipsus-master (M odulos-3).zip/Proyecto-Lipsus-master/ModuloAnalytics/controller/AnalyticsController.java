
package ModuloAnalytics.controller;

import ModuloAnalytics.dto.AnalyticsResponse;
import ModuloAnalytics.service.AnalyticsService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/analytics")
public class AnalyticsController {

    private final AnalyticsService analyticsService;

    public AnalyticsController(AnalyticsService analyticsService) {
        this.analyticsService = analyticsService;
    }

    @GetMapping("/user/{userId}")
    public AnalyticsResponse getUserStatistics(@PathVariable Long userId) {
        return analyticsService.getUserStatistics(userId);
    }
}
