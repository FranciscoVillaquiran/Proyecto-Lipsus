package ModuloAnalytics.dto;

public class AnalyticsResponse {

    private Long userId;
    private int totalSubmissions;
    private int successfulSubmissions;
    private double successRate;
    private double averageScore;

    public AnalyticsResponse(Long userId, int totalSubmissions, int successfulSubmissions, double successRate, double averageScore) {
        this.userId = userId;
        this.totalSubmissions = totalSubmissions;
        this.successfulSubmissions = successfulSubmissions;
        this.successRate = successRate;
        this.averageScore = averageScore;
    }

    public Long getUserId() {
        return userId;
    }

    public int getTotalSubmissions() {
        return totalSubmissions;
    }

    public int getSuccessfulSubmissions() {
        return successfulSubmissions;
    }

    public double getSuccessRate() {
        return successRate;
    }

    public double getAverageScore() {
        return averageScore;
    }
}
