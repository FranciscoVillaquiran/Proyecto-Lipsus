package ModuloAnalytics.service;

import ModuloAnalytics.dto.AnalyticsResponse;
import ModuloSubmissions.model.Submission;
import ModuloSubmissions.repository.SubmissionRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AnalyticsService {

    private final SubmissionRepository submissionRepository;

    public AnalyticsService(SubmissionRepository submissionRepository) {
        this.submissionRepository = submissionRepository;
    }

    public AnalyticsResponse getUserStatistics(Long userId) {
        List<Submission> submissions = submissionRepository.findByUserId(userId);

        int totalSubmissions = submissions.size();

        int successfulSubmissions = (int) submissions.stream()
                .filter(s -> "ACCEPTED".equals(s.getStatus()))
                .count();

                double successRate = totalSubmissions == 0 ? 0 : (double) successfulSubmissions / totalSubmissions * 100;

                double averageScore = succesRate; //por ahora simple

                return new AnalyticsResponse(
                    userId,
                    totalSubmissions,
                    successfulSubmissions,
                    successRate,
                    averageScore
                );
    }
}
