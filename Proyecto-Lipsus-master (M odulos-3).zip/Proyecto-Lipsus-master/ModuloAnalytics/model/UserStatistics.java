package ModuloAnalytics.model;

public class UserStatistics {

    private Long userId;
    private int totalSubmissions;
    private int successfulSubmissions;
    private double successRate;
    private double averageScore;

    public UserStatistics() {}

    public UserStatistics(Long userId, int totalSubmissions, int successfulSubmissions, double successRate, double averageScore) {
        this.userId = userId;
        this.totalSubmissions = totalSubmissions;
        this.successfulSubmissions = successfulSubmissions;
        this.successRate = successRate;
        this.averageScore = averageScore;
    }

    public Long getUserId() {
        return userId;
    }

    public int getTotalSubmissions() {
        return totalSubmissions;
    }

    public int getSuccessfulSubmissions() {
        return successfulSubmissions;
    }

    public double getSuccessRate() {
        return successRate;
    }

    public double getAverageScore() {
        return averageScore;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public void setTotalSubmissions(int totalSubmissions) {
        this.totalSubmissions = totalSubmissions;
    }

    public void setSuccessfulSubmissions(int successfulSubmissions) {
        this.successfulSubmissions = successfulSubmissions;
    }

    public void setSuccessRate(double successRate) {
        this.successRate = successRate;
    }

    public void setAverageScore(double averageScore) {
        this.averageScore = averageScore;
    }
}
