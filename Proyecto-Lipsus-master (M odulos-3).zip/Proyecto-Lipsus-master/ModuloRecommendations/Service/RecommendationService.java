package ModuloRecommendations.service;

import ModuloRecommendations.dto.RecommendationResponse;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class RecommendationService {

    public List<RecommendationResponse> getRecommendations(Long userId) {

        // Simulación simple basada en reglas
        List<RecommendationResponse> recommendations = new ArrayList<>();

        recommendations.add(
                new RecommendationResponse(
                        1L,
                        "Two Sum",
                        "Easy"
                )
        );

        recommendations.add(
                new RecommendationResponse(
                        5L,
                        "Reverse String",
                        "Easy"
                )
        );

        recommendations.add(
                new RecommendationResponse(
                        12L,
                        "Binary Search",
                        "Medium"
                )
        );

        return recommendations;
    }
}
