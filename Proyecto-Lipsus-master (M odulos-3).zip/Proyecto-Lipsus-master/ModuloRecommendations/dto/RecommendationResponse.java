package ModuloRecommendations.dto;

public class RecommendationResponse {

    private Long problemId;
    private String title;
    private String difficulty;

    public RecommendationResponse(Long problemId, String title, String difficulty) {
        this.problemId = problemId;
        this.title = title;
        this.difficulty = difficulty;
    }

    public Long getProblemId() {
        return problemId;
    }

    public String getTitle() {
        return title;
    }

    public String getDifficulty() {
        return difficulty;
    }
}
